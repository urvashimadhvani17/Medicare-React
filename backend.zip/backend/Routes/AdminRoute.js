import express from "express";
import bcrypt from "bcryptjs";
import Admin from "../Model/Admin.js";

const router = express.Router();

/* -------------------------------------------
   ✅ ADMIN LOGIN ROUTE (Static + Database)
--------------------------------------------*/
router.post("/login", async (req, res) => {
  try {
    const { adminname, password } = req.body;

    // ✅ 1️⃣ Static admin login
    if (adminname === "admin" && password === "admin@123") {
      return res.status(200).json({
        success: true,
        message: "Static Admin Login Successful",
        admin: { adminname: "admin" },
      });
    }

    // ✅ 2️⃣ Dynamic admin login (from database)
    const existingAdmin = await Admin.findOne({ adminname });

    if (!existingAdmin) {
      return res.status(404).json({
        success: false,
        message: "Admin not found",
      });
    }

    // ✅ Compare entered password with hashed password
    const isMatch = await bcrypt.compare(password, existingAdmin.password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid password",
      });
    }

    // ✅ Login successful
    res.status(200).json({
      success: true,
      message: "Admin login successful",
      admin: {
        id: existingAdmin._id,
        adminname: existingAdmin.adminname,
        email: existingAdmin.email,
      },
    });
  } catch (error) {
    console.error("❌ Login error:", error);
    res.status(500).json({
      success: false,
      message: "Server error, please try again later",
      error: error.message,
    });
  }
});

export default router;
