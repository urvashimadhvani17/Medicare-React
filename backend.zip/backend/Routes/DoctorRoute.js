import express from "express";
import bcrypt from "bcryptjs";
import Doctor from "../Model/Doctor.js";

const router = express.Router();

/* ---------------------- REGISTER DOCTOR ---------------------- */
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, specialization, contact } = req.body;

    if (!name || !email || !password || !specialization || !contact) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // check existing doctor
    const existing = await Doctor.findOne({ email });
    if (existing) {
      return res.status(400).json({ message: "Email already exists" });
    }

    // hash password  
    const hashedPassword = await bcrypt.hash(password, 10);

    const newDoctor = new Doctor({
      name,
      email,
      password: hashedPassword,
      specialization,
      contact,
    });

    await newDoctor.save();

    res.status(201).json({ message: "Doctor Registered Successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
});

/* ---------------------- LOGIN DOCTOR ---------------------- */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const doctor = await Doctor.findOne({ email });
    if (!doctor) {
      return res.status(400).json({ message: "Invalid Email or Password" });
    }

    const match = await bcrypt.compare(password, doctor.password);
    if (!match) {
      return res.status(400).json({ message: "Invalid Email or Password" });
    }

    res.json({
      message: "Login Successful",
      doctor: {
        _id: doctor._id,
        name: doctor.name,
        email: doctor.email,
        specialization: doctor.specialization,
        contact: doctor.contact
      }
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* ---------------------- GET ALL DOCTORS ---------------------- */
router.get("/", async (req, res) => {
  try {
    const doctors = await Doctor.find().select("-password");
    res.json(doctors);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* ---------------------- UPDATE DOCTOR ---------------------- */
router.put("/:id", async (req, res) => {
  try {
    const { password, ...updateData } = req.body;

    if (password) {
      updateData.password = await bcrypt.hash(password, 10);
    }

    const updated = await Doctor.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true
    });

    if (!updated) {
      return res.status(404).json({ message: "Doctor not found" });
    }

    res.json({ message: "Updated", updated });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* ---------------------- DELETE DOCTOR ---------------------- */
router.delete("/:id", async (req, res) => {
  try {
    const deleted = await Doctor.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ message: "Doctor not found" });
    }

    res.json({ message: "Deleted successfully" });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
