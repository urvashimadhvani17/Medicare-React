import express from "express";
import bcrypt from "bcryptjs";
import Patient from "../Model/Patient.js";

const router = express.Router();

/* REGISTER PATIENT */
router.post("/register", async (req, res) => {
  try {
    const { name, email, disease, contact, password } = req.body;

    if (!name || !email || !disease || !contact || !password)
      return res.status(400).json({ message: "All fields required" });

    const exist = await Patient.findOne({ email });
    if (exist) return res.status(400).json({ message: "Email exists" });

    const hashed = await bcrypt.hash(password, 10);

    await new Patient({
      name,
      email,
      disease,
      contact,
      password: hashed
    }).save();

    res.json({ message: "Patient registered" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* LOGIN PATIENT */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ message: "Email and password are required" });

    const patient = await Patient.findOne({ email });
    if (!patient)
      return res.status(400).json({ message: "Invalid Email or Password" });

    const isMatch = await bcrypt.compare(password, patient.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid Email or Password" });

    res.json({
      message: "Login Successful",
      patient: {
        _id: patient._id,
        name: patient.name,
        email: patient.email,
        disease: patient.disease,
        contact: patient.contact
      }
    });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/* GET ALL PATIENTS */
router.get("/", async (req, res) => {
  res.json(await Patient.find());
});

/* UPDATE PATIENT */
router.put("/:id", async (req, res) => {
  try {
    const updated = await Patient.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json({ message: "Patient updated", updated });
  } catch {
    res.status(500).json({ message: "Update failed" });
  }
});

/* DELETE PATIENT */
router.delete("/:id", async (req, res) => {
  try {
    await Patient.findByIdAndDelete(req.params.id);
    res.json({ message: "Patient deleted" });
  } catch {
    res.status(500).json({ message: "Delete failed" });
  }
});

export default router;
