    import express from "express";
    import cors from "cors";
    import dotenv from "dotenv";
    import connectDB from "./config/db.js";

    // ✅ Import all routes
    import adminRoute from "./Routes/AdminRoute.js";
    import doctorRoute from "./Routes/DoctorRoute.js";
    import patientRoute from "./Routes/PatientRoute.js";
    import appointmentRoute from "./Routes/ApptRoute.js";
    import contactRoute from "./Routes/ContactRoute.js";

    // ✅ Initialize environment and app
    dotenv.config();
    const app = express();
    const PORT = process.env.PORT || 5000;

    // ✅ Middleware
    app.use(cors());
    app.use(express.json());

    // ✅ Connect to MongoDB
    connectDB();

    // ✅ Routes
    app.use("/api/admin", adminRoute);
    app.use("/api/doctor", doctorRoute);
    app.use("/api/patient", patientRoute);
    app.use("/api/appointment", appointmentRoute);
    app.use("/api/contact", contactRoute);

    // ✅ Default route (health check)
    app.get("/", (req, res) => {
      res.send("🚀 Medicore Backend API is running successfully!");
    });

    // ✅ Start server
    app.listen(PORT, () =>
      console.log(`🚀 Server running on http://localhost:${PORT}`)
    );
