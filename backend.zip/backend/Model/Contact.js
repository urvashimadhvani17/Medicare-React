import mongoose from "mongoose";

const contactSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  message: { type: String, required: true, unique: true },
  createdAt: { type: Date, default: Date.now }
});

// Compound index (all fields unique together)
contactSchema.index(
  { name: 1, email: 1, message: 1 },
  { unique: true }
);

const Contact = mongoose.model("Contact", contactSchema, "contacts");

export default Contact;
