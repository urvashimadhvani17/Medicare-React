
import React from "react";

export default function PatientDashboard() {
  return <h2>Patient Dashboard</h2>;
}
