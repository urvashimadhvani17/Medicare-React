import React from "react";
import "../Pages/style.css";
import "../Pages/home.css";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

export default function Home() {
  return (
    <div className="app-container">
      <Sidebar />

      <div className="content-wrapper">
        <Header />

        <main className="main-content">

          <h1>Welcome to MediCore Platform</h1>
          <p>Healing through technology and caring design for better health</p>

          {/* ==================== BOOTSTRAP SLIDER ==================== */}
          <div className="carousel-wrapper">
            <div
              id="carouselExample"
              className="carousel slide"
              data-bs-ride="carousel"
            >
              {/* Indicators */}
              <div className="carousel-indicators">
                <button
                  type="button"
                  data-bs-target="#carouselExample"
                  data-bs-slide-to="0"
                  className="active"
                  aria-current="true"
                  aria-label="Slide 1"
                ></button>
                <button
                  type="button"
                  data-bs-target="#carouselExample"
                  data-bs-slide-to="1"
                  aria-label="Slide 2"
                ></button>
                <button
                  type="button"
                  data-bs-target="#carouselExample"
                  data-bs-slide-to="2"
                  aria-label="Slide 3"
                ></button>
              </div>

              {/* Slides */}
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img
                    src="/Images/Slider/img1.jpg"
                    className="d-block w-100"
                    alt="Slide 1"
                  />
                </div>

                <div className="carousel-item">
                  <img
                    src="/Images/Slider/img2.jpg"
                    className="d-block w-100"
                    alt="Slide 2"
                  />
                </div>

                <div className="carousel-item">
                  <img
                    src="/Images/Slider/img3.jpg"
                    className="d-block w-100"
                    alt="Slide 3"
                  />
                </div>
              </div>

              {/* Prev Button */}
              <button
                className="carousel-control-prev"
                type="button"
                data-bs-target="#carouselExample"
                data-bs-slide="prev"
              >
                <span
                  className="carousel-control-prev-icon bg-dark rounded-circle"
                  aria-hidden="true"
                ></span>
                <span className="visually-hidden">Previous</span>
              </button>

              {/* Next Button */}
              <button
                className="carousel-control-next"
                type="button"
                data-bs-target="#carouselExample"
                data-bs-slide="next"
              >
                <span
                  className="carousel-control-next-icon bg-dark rounded-circle"
                  aria-hidden="true"
                ></span>
                <span className="visually-hidden">Next</span>
              </button>
            </div>
          </div>


          {/* ==================== QUICK STATS ==================== */}
          <div className="stats-section">
            <div className="stat-box"><h2>20+</h2><p>Specialized Services</p></div>
            <div className="stat-box"><h2>100+</h2><p>Appointments Daily</p></div>
            <div className="stat-box"><h2>50+</h2><p>Expert Doctors</p></div>
            <div className="stat-box"><h2>500+</h2><p>Patients Treated</p></div>
          </div>

          {/* ==================== WHY CHOOSE US ==================== */}
          <div className="choose-section">
            <h2>Why Choose MediCore?</h2>
            <div className="choose-grid">
              <div className="choose-card">24/7 Online Support</div>
              <div className="choose-card">Expert Medical Staff</div>
              <div className="choose-card">Easy Appointments</div>
              <div className="choose-card">Secure Health Records</div>
            </div>
          </div>

          {/* ==================== SERVICES ==================== */}
          <div className="services-section">
            <h2>Our Services</h2>

            <div className="row mt-3">

              <div className="col-md-6 mb-3">
                <div className="service-card">Cardiology</div>
              </div>

              <div className="col-md-6 mb-3">
                <div className="service-card">Neurology</div>
              </div>

              <div className="col-md-6 mb-3">
                <div className="service-card">Pediatrics</div>
              </div>

              <div className="col-md-6 mb-3">
                <div className="service-card">Emergency Care</div>
              </div>

            </div>
          </div>

          {/* ==================== DOCTORS ==================== */}
          <div className="doctors-section">
            <h2>Meet Our Doctors</h2>

            <div className="doctor-card">
              <img src="/Images/Slider/doc1.jpg" className="doctor-img" alt="Doctor 1" />
              <p>Dr. Sharma (Cardiologist)</p>
            </div>

            <div className="doctor-card">
              <img src="/Images/Slider/doc2.jpg" className="doctor-img" alt="Doctor 2" />
              <p>Dr. Patel (Neurologist)</p>
            </div>

            <div className="doctor-card">
              <img src="/Images/Slider/doc3.jpg" className="doctor-img" alt="Doctor 3" />
              <p>Dr. Mehta (Pediatrician)</p>
            </div>
          </div>

          {/* ==================== TESTIMONIALS ==================== */}
          <div className="testimonials-section">
            <h2>What Our Patients Say</h2>
            <div className="testimonials-grid">
              <div className="testimonial-card">
                <p>"MediCore made booking so easy. Highly recommend!"</p>
                <span>- Riya Sharma</span>
              </div>
              <div className="testimonial-card">
                <p>"Best doctors and quick online consultation."</p>
                <span>- Amit Verma</span>
              </div>
            </div>
          </div>

          {/* ==================== EMERGENCY BANNER ==================== */}
          <div className="emergency-banner">
            <h2>🚨 Emergency?</h2>
            <p>Call 108 or +91-9876543210 for immediate help</p>
          </div>

        </main>

      </div>

      <Footer />
    </div>
  );
}
