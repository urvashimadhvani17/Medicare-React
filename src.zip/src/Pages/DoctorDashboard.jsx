
import React from "react";

export default function DoctorDashboard() {
  return <h2>Doctor Dashboard</h2>;
}
