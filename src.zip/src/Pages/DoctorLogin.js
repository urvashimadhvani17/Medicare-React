import React, { useState, useEffect } from "react";
import "../Pages/style.css";
import "../Pages/docstyle.css";
import axios from "axios";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

/* ---------------- Safe LocalStorage Helpers ---------------- */
const safeGet = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const safeSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
const safeRemove = (k) => { try { localStorage.removeItem(k); } catch {} };

export default function DoctorLogin() {
  const [mode, setMode] = useState("login");
  const [showPatients, setShowPatients] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    specialization: "",
    contact: ""
  });

  const [currentDoctor, setCurrentDoctor] = useState(null);
  const [patients, setPatients] = useState([]);

  /* ---------------- Patient Add/Edit ---------------- */
  const [showBox, setShowBox] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);

  const [patientForm, setPatientForm] = useState({
    name: "",
    email: "",
    password: "",
    disease: "",
    contact: ""
  });

  /* ---------------- Load Saved Doc ---------------- */
  useEffect(() => {
    const saved = safeGet("doctorUser");
    if (saved) {
      setCurrentDoctor(saved);
      setMode("dashboard");
      fetchPatients();
    }
  }, []);

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  /* ---------------- Doctor Register (💯 FIXED) ---------------- */
  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/doctor/register", {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        specialization: formData.specialization,
        contact: formData.contact
      });

      alert(res.data.message || "Registered Successfully!");
      setMode("login");

      setFormData({ name: "", email: "", password: "", specialization: "", contact: "" });
    } catch (err) {
      alert("Register failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* ---------------- Doctor Login ---------------- */
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/doctor/login", {
        email: formData.email,
        password: formData.password
      });

      const d = res.data.doctor;
      const obj = { name: d.name, email: d.email, specialization: d.specialization, contact: d.contact };

      safeSet("doctorUser", obj);
      setCurrentDoctor(obj);
      setMode("dashboard");
      setShowPatients(false);
      fetchPatients();
    } catch (err) {
      alert("Login failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* ---------------- Fetch Patients ---------------- */
  const fetchPatients = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/patient");
      setPatients(res.data);
    } catch {}
  };

  const handleLogout = () => {
    safeRemove("doctorUser");
    setCurrentDoctor(null);
    setMode("login");
  };

  const openAddBox = () => {
    setSelectedPatient(null);
    setShowBox(true);
    setPatientForm({ name: "", email: "", password: "", disease: "", contact: "" });
  };

  const openEditBox = (p) => {
    setSelectedPatient(p);
    setShowBox(true);
    setPatientForm({ name: p.name, email: p.email, password: "", disease: p.disease, contact: p.contact });
  };

  const handlePatientChange = (e) => setPatientForm({ ...patientForm, [e.target.name]: e.target.value });

  /* ---------------- Add / Update Patient ---------------- */
  const handleSavePatient = async (e) => {
    e.preventDefault();
    try {
      if (selectedPatient) {
        await axios.put(`http://localhost:5000/api/patient/${selectedPatient._id}`, patientForm);
        alert("Patient Updated!");
      } else {
        await axios.post("http://localhost:5000/api/patient/register", patientForm);
        alert("Patient Added!");
      }
      setShowBox(false);
      fetchPatients();
    } catch (err) {
      alert("Failed: " + (err.response?.data?.message || err.message));
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete ${name}?`)) return;
    try {
      await axios.delete(`http://localhost:5000/api/patient/${id}`);
      alert("Deleted!");
      fetchPatients();
    } catch {}
  };

  /* ---------------- UI ---------------- */
  return (
    <div className="container">
      <Sidebar />
      <div className="contentWrapper">
        <Header />
        <main className="mainContent">

          {/* -------- REGISTER -------- */}
          {mode === "register" && (
            <div className="login-box">
              <h2>Doctor Register</h2>
              <form onSubmit={handleRegister}>
                <label>Name</label><input name="name" value={formData.name} onChange={handleChange} required />
                <label>Email</label><input name="email" type="email" value={formData.email} onChange={handleChange} required />
                <label>Password</label><input name="password" type="password" value={formData.password} onChange={handleChange} required />
                <label>Specialization</label><input name="specialization" value={formData.specialization} onChange={handleChange} required />
                <label>Contact</label><input name="contact" value={formData.contact} onChange={handleChange} required />
                <button type="submit">Register</button>
              </form>
              <p>Already have account? <span className="link" onClick={() => setMode("login")}>Login</span></p>
            </div>
          )}

          {/* -------- LOGIN -------- */}
          {mode === "login" && (
            <div className="login-box">
              <h2>Doctor Login</h2>
              <form onSubmit={handleLogin}>
                <label>Email</label><input name="email" value={formData.email} onChange={handleChange} required />
                <label>Password</label><input name="password" type="password" value={formData.password} onChange={handleChange} required />
                <button type="submit">Login</button>
              </form>
              <p>New doctor? <span className="link" onClick={() => setMode("register")}>Register here</span></p>
            </div>
          )}

          {/* -------- DASHBOARD -------- */}
          {mode === "dashboard" && currentDoctor && (
            <>
              {!showPatients && (
                <div className="welcome-box fade-in">
                  <h2>Welcome, Dr. {currentDoctor.name}</h2>
                  <button className="btn btn-primary" onClick={() => setShowPatients(true)}>Manage Patients</button>
                  <button className="btn btn-danger ms-2" onClick={handleLogout}>Logout</button>
                </div>
              )}

              {showPatients && (
                <>
                  <button className="btn btn-secondary mb-3" onClick={() => setShowPatients(false)}>← Back</button>

                  <button className="btn btn-success mb-3" onClick={openAddBox}>+ Add Patient</button>

                  {showBox && (
                    <div className="login-box mt-4 fade-in" style={{ width: "600px" }}>
                      <h3>{selectedPatient ? "Edit Patient" : "Add Patient"}</h3>
                      <form onSubmit={handleSavePatient}>
                        <div className="row">
                          <div className="col-md-6"><label>Name</label><input name="name" value={patientForm.name} onChange={handlePatientChange} required /></div>
                          <div className="col-md-6"><label>Email</label><input name="email" value={patientForm.email} onChange={handlePatientChange} required /></div>
                        </div>

                        {!selectedPatient && (
                          <div className="row mt-3">
                            <div className="col-md-6"><label>Password</label><input name="password" type="password" value={patientForm.password} onChange={handlePatientChange} required /></div>
                            <div className="col-md-6"><label>Disease</label><input name="disease" value={patientForm.disease} onChange={handlePatientChange} required /></div>
                          </div>
                        )}

                        {selectedPatient && (
                          <div className="row mt-3">
                            <div className="col-md-6"><label>Disease</label><input name="disease" value={patientForm.disease} onChange={handlePatientChange} required /></div>
                            <div className="col-md-6"><label>Contact</label><input name="contact" value={patientForm.contact} onChange={handlePatientChange} required /></div>
                          </div>
                        )}

                        {!selectedPatient && (
                          <div className="row mt-3">
                            <div className="col-md-6"><label>Contact</label><input name="contact" value={patientForm.contact} onChange={handlePatientChange} required /></div>
                          </div>
                        )}

                        <div className="patient-btn-row">
                          <button type="submit" className="btn btn-primary mt-3">{selectedPatient ? "Update Patient" : "Add Patient"}</button>
                          <button type="button" className="btn btn-secondary mt-3 ms-2" onClick={() => setShowBox(false)}>Cancel</button>
                        </div>
                      </form>
                    </div>
                  )}

                  <table className="doctor-table mt-4">
                    <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Disease</th><th>Contact</th><th>Action</th></tr></thead>
                    <tbody>
                      {patients.length > 0 ? patients.map((p, i) => (
                        <tr key={p._id}>
                          <td>{i + 1}</td><td>{p.name}</td><td>{p.email}</td><td>{p.disease}</td><td>{p.contact}</td>
                          <td>
                            <button className="edit-btn" onClick={() => openEditBox(p)}>✏️ Edit</button>
                            <button className="delete-btn" onClick={() => handleDelete(p._id, p.name)}> 🗑️ Delete</button>
                          </td>
                        </tr>
                      )) : (<tr><td colSpan="6">No patients found</td></tr>)}
                    </tbody>
                  </table>

                </>
              )}
            </>
          )}
        </main>
        <Footer />
      </div>
    </div>
  );
}
