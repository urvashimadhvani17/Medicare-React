import React, { useState, useEffect } from "react";
import axios from "axios";
import "../Pages/style.css";
import "../Pages/patient.css";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

/* -------------------- Safe LocalStorage helpers -------------------- */
const safeGet = (key) => {
  try {
    if (typeof window !== "undefined") {
      return JSON.parse(localStorage.getItem(key));
    }
  } catch {
    return null;
  }
};

const safeSet = (key, value) => {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(key, JSON.stringify(value));
    }
  } catch { }
};

const safeRemove = (key) => {
  try {
    if (typeof window !== "undefined") {
      localStorage.removeItem(key);
    }
  } catch { }
};

export default function PatientLogin() {
  const [mode, setMode] = useState("login");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    disease: "",
    contact: "",
    specialization: "",
  });

  const [currentPatient, setCurrentPatient] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [showDoctors, setShowDoctors] = useState(false);

  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [showDoctorAddBox, setShowDoctorAddBox] = useState(false);

  /* -------------------- Load saved patient -------------------- */
  useEffect(() => {
    const saved = safeGet("patientUser");
    if (saved) {
      setCurrentPatient(saved);
      setMode("dashboard");
    }
  }, []);

  /* -------------------- Fetch Doctors -------------------- */
  const fetchDoctors = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/doctor");
      setDoctors(res.data);
    } catch (err) {
      console.error("Error fetching doctors:", err);
    }
  };

  /* -------------------- Input Handler -------------------- */
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  /* -------------------- Register Patient -------------------- */
  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/patient/register", formData);

      alert("Registered Successfully!");

      setFormData({
        name: "",
        email: "",
        password: "",
        disease: "",
        contact: "",
      });

      setMode("login");
    } catch (err) {
      alert("❌ Registration Failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- Patient Login -------------------- */
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/patient/login", {
        email: formData.email,
        password: formData.password,
      });

      const p = res.data.patient;

      const fullPatient = {
        name: p.name,
        email: p.email,
        disease: p.disease,
        contact: p.contact,
      };

      setCurrentPatient(fullPatient);
      safeSet("patientUser", fullPatient);
      setMode("dashboard");

      alert("Login Successful!");

    } catch (err) {
      alert("❌ Login Failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- Logout -------------------- */
  const handleLogout = () => {
    safeRemove("patientUser");
    setCurrentPatient(null);
    setMode("login");
    setShowDoctors(false);
  };

  /* -------------------- EDIT DOCTOR -------------------- */
  const handleEdit = (doctor) => {
    setSelectedDoctor(doctor);
    setShowDoctorAddBox(true);

    setFormData({
      name: doctor.name,
      email: doctor.email,
      specialization: doctor.specialization,
      contact: doctor.contact,
      password: "",
    });
  };

  /* -------------------- UPDATE DOCTOR -------------------- */
  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!selectedDoctor) return alert("No doctor selected!");

    try {
      await axios.put(`http://localhost:5000/api/doctor/${selectedDoctor._id}`, formData);

      alert("Doctor updated successfully!");

      setSelectedDoctor(null);
      setShowDoctorAddBox(false);

      setFormData({
        name: "",
        email: "",
        password: "",
        disease: "",
        contact: "",
        specialization: "",
      });

      fetchDoctors();
    } catch (err) {
      alert("❌ Update failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- DELETE DOCTOR -------------------- */
  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete ${name}?`)) return;

    try {
      await axios.delete(`http://localhost:5000/api/doctor/${id}`);
      alert("Doctor deleted!");
      fetchDoctors();
    } catch (err) {
      alert("❌ Delete failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- ADD NEW DOCTOR -------------------- */
  const handleDoctorRegister = async (e) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:5000/api/doctor/register", {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        specialization: formData.specialization,
        contact: formData.contact,
      });

      alert("Doctor Added Successfully!");

      setFormData({
        name: "",
        email: "",
        password: "",
        disease: "",
        contact: "",
        specialization: "",
      });

      setShowDoctorAddBox(false);
      fetchDoctors();
    } catch (err) {
      alert("❌ Doctor Add Failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- UI Rendering -------------------- */
  return (
    <div className="container">
      <Sidebar />

      <div className="contentWrapper">
        <Header />

        <main className="mainContent">

          {/* -------------------- PATIENT REGISTRATION -------------------- */}
          {mode === "register" && (
            <div className="login-box">
              <h2>Patient Registration</h2>

              <form onSubmit={handleRegister}>
                <label>Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required />

                <label>Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} required />

                <label>Password</label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} required />

                <label>Disease</label>
                <input type="text" name="disease" value={formData.disease} onChange={handleChange} required />

                <label>Contact</label>
                <input type="tel" name="contact" value={formData.contact} onChange={handleChange} required />

                <button type="submit">Register</button>
              </form>

              <p>
                Already registered?{" "}
                <span className="link" onClick={() => setMode("login")}>Login here</span>
              </p>
            </div>
          )}

          {/* -------------------- PATIENT LOGIN -------------------- */}
          {mode === "login" && (
            <div className="login-box">
              <h2>Patient Login</h2>

              <form onSubmit={handleLogin}>
                <label>Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} required />

                <label>Password</label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} required />

                <button type="submit">Login</button>
              </form>

              <p>
                New user?{" "}
                <span className="link" onClick={() => setMode("register")}>Register here</span>
              </p>
            </div>
          )}

          {/* -------------------- DASHBOARD -------------------- */}
          {mode === "dashboard" && currentPatient && (
            <>
              {!showDoctors && (
                <div className="welcome-box">
                  <h2>Welcome, {currentPatient.name}</h2>
                  <p><strong>Disease:</strong> {currentPatient.disease}</p>
                  <p><strong>Contact:</strong> {currentPatient.contact}</p>

                  <button
                    className="btn btn-success"
                    onClick={() => {
                      setShowDoctors(true);
                      fetchDoctors();
                    }}
                  >
                    View Doctors
                  </button>

                  <button className="btn btn-danger" onClick={handleLogout}>
                    Logout
                  </button>
                </div>
              )}

              {/* -------------------- DOCTOR TABLE + ADD/EDIT FORM -------------------- */}
              {showDoctors && (
                <div className="table-section fade-in">

                  <button
                    className="btn btn-secondary mb-3"
                    onClick={() => setShowDoctors(false)}
                  >
                    ← Back
                  </button>

                  <div className="d-flex justify-content-between align-items-center">
                    <h3>Available Doctors</h3>

                    <button
                       className="btn btn-primary"
                      onClick={() => {
                        setSelectedDoctor(null);
                        setFormData({
                          name: "",
                          email: "",
                          password: "",
                          disease: "",
                          contact: "",
                          specialization: "",
                        });
                        setShowDoctorAddBox(true);
                      }}
                    >
                      + Add Doctor
                    </button>
                  </div>

                  {/* -------------------- ADD / EDIT DOCTOR FORM -------------------- */}
                  {showDoctorAddBox && (
                    <div className="login-box fade-in mt-4" style={{ width: "600px" }}>
                      <h3>{selectedDoctor ? "Edit Doctor" : "Add New Doctor"}</h3>

                      <form onSubmit={selectedDoctor ? handleUpdate : handleDoctorRegister}>

                        <div className="row">
                          <div className="col-md-6">
                            <label>Name</label>
                            <input
                              type="text"
                              name="name"
                              value={formData.name}
                              onChange={handleChange}
                              required
                            />
                          </div>

                          <div className="col-md-6">
                            <label>Email</label>
                            <input
                              type="email"
                              name="email"
                              value={formData.email}
                              onChange={handleChange}
                              required
                            />
                          </div>
                        </div>

                        <div className="row mt-3">
                          <div className="col-md-6">
                            <label>Password</label>
                            <input
                              type="password"
                              name="password"
                              value={formData.password}
                              onChange={handleChange}
                              required={!selectedDoctor}
                            />
                          </div>

                          <div className="col-md-6">
                            <label>Specialization</label>
                            <input
                              type="text"
                              name="specialization"
                              value={formData.specialization}
                              onChange={handleChange}
                              required
                            />
                          </div>
                        </div>

                        <div className="row mt-3">
                          <div className="col-md-6">
                            <label>Contact</label>
                            <input
                              type="tel"
                              name="contact"
                              value={formData.contact}
                              onChange={handleChange}
                              required
                            />
                          </div>
                        </div>
                      <div className="btn-row">
                        <button type="submit" className="btn btn-primary mt-3">
                          {selectedDoctor ? "Update Doctor" : "Add Doctor"}
                        </button>

                        <button
                          type="button"
                          className="btn btn-secondary mt-3 ms-2"
                          onClick={() => setShowDoctorAddBox(false)}
                        >
                          Cancel
                        </button>
                    </div>
                      </form>
                    </div>
                  )}


                  {/* -------------------- DOCTOR TABLE -------------------- */}
                  <table className="doctor-table mt-4">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Specialization</th>
                        <th>Contact</th>
                        <th>Actions</th>
                      </tr>
                    </thead>

                    <tbody>
                      {doctors.length > 0 ? (
                        doctors.map((d, i) => (
                          <tr key={d._id}>
                            <td>{i + 1}</td>
                            <td>{d.name}</td>
                            <td>{d.email}</td>
                            <td>{d.specialization}</td>
                            <td>{d.contact}</td>
                            <td>
                              <button
                                className="btn-edit"
                                onClick={() => handleEdit(d)}
                              >
                                ✏️ Edit
                              </button>

                              <button
                                className="btn-delete"
                                onClick={() => handleDelete(d._id, d.name)}
                              >
                                🗑️ Delete
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="6">No doctors found.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>

                </div>
              )}
            </>
          )}

        </main>

        <Footer />
      </div>
    </div>
  );
}
