import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Header from "../Components/Header";
import Sidebar from "../Components/Sidebar";
import Footer from "../Components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "../Pages/style.css";
import "../Pages/addstyle.css";

export default function AdminLogin() {
  const [formData, setFormData] = useState({
    adminname: "",
    password: "",
  });

  const [loggedIn, setLoggedIn] = useState(false);
  const [currentAdmin, setCurrentAdmin] = useState(null);

  // ✅ Safe Local Storage Helper
  const safeStorage = {
    get(key) {
      try {
        return localStorage.getItem(key);
      } catch (err) {
        console.warn("⚠️ localStorage not accessible:", err);
        return null;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, value);
      } catch (err) {
        console.warn("⚠️ localStorage write blocked:", err);
      }
    },
    remove(key) {
      try {
        localStorage.removeItem(key);
      } catch (err) {
        console.warn("⚠️ localStorage remove blocked:", err);
      }
    },
  };

  // ✅ Load saved admin if already logged in
  useEffect(() => {
    const savedAdmin = safeStorage.get("adminUser");
    if (savedAdmin) {
      setCurrentAdmin(JSON.parse(savedAdmin));
      setLoggedIn(true);
    }
  }, []);

  // ✅ Handle input
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ✅ Static login verification
  const handleSubmit = async (e) => {
    e.preventDefault();
    const { adminname, password } = formData;

    if (!adminname || !password) {
      alert("⚠️ Please fill all fields");
      return;
    }

    // ✅ Check fixed static credentials
    if (adminname === "admin" && password === "admin@123") {
      const adminData = { adminname: "admin" };
      safeStorage.set("adminUser", JSON.stringify(adminData));
      setCurrentAdmin(adminData);
      setLoggedIn(true);
      alert("✅ Login Successful (Local Admin)");
    } else {
      alert("❌ Invalid Username or Password");
    }
  };

  // ✅ Handle logout 
  const handleLogout = () => {
    safeStorage.remove("adminUser");
    setFormData({ adminname: "", password: "" });
    setLoggedIn(false);
    setCurrentAdmin(null);
  };

  return (
    <div className="container">
      <Sidebar />
      <div className="content-wrapper">
        <Header />

        <main className="main-content admin-page">
          {!loggedIn ? (
            <div className="login-section">
              <h2>Admin Login</h2>
              <div className="login-container">
                <form className="login-form" onSubmit={handleSubmit}>
                  <label htmlFor="adminname">Username</label>
                  <input
                    type="text"
                    id="adminname"
                    name="adminname"
                    placeholder="Enter your username"
                    value={formData.adminname}
                    onChange={handleChange}
                    required
                  />

                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />

                  <button
                    type="submit"
                    className="btn btn-primary w-100 mt-3"
                  >
                    Login
                  </button>
                </form>
              </div>
            </div>
          ) : (
         <div class name="main-content">
            <div className="dashboard">
              <div className="headerRow">
                <h1>Welcome {currentAdmin?.adminname} </h1>
                <button
                  className="logoutButton btn btn-danger"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </div>

              <div className="welcome-card mt-4">
                <h3>Welcome, Admin!</h3>
                <p>
                  You are logged in as an administrator. Use the links below to
                  manage the platform.
                </p>
              </div>

              <div className="dashboard-grid mt-4">
                <Link to="/doctor-login" className="dashboard-card-link">
                  <i className="fas fa-user-md"></i>
                  <h3>Manage Doctors</h3>
                </Link>

                <Link to="/patient-login" className="dashboard-card-link">
                  <i className="fas fa-users"></i>
                  <h3>View Patients</h3>
                </Link>

                <Link to="/appointment" className="dashboard-card-link">
                  <i className="fas fa-calendar-alt"></i>
                  <h3>Manage Appointments</h3>
                </Link>

                <Link to="/contact" className="dashboard-card-link">
                  <i className="fas fa-envelope-open-text"></i>
                  <h3>View Contact Details</h3>
                </Link>
              </div>
            </div>
            </div>
          )}
        </main>

        <Footer />
      </div>
    </div>
  );
}
