import React, { useState } from "react";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import "../Pages/style.css";
import "../Pages/contact.css";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false); // ✅ to toggle success message

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok) {
        setIsSubmitted(true); // ✅ show success message
        setFormData({ name: "", email: "", message: "" });
        alert(result.message || "send Message Successfully.");

      } else {
        alert(result.message || "Failed to send message.");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Failed to send message. Try again later.");
    }
  };

  return (
    <div className="container">
      {/* Sidebar */}
      <Sidebar />

      {/* Right Content */}
      <div className="content-wrapper">
        {/* Header */}
        <Header />

        {/* Main Content */}
        <main className="main-content">
          {!isSubmitted ? (
            <>
              <h2 className="contact-title">Contact Us</h2>

              <div className="contact-content-wrapper">
                {/* Left Side: Form */}
                <div className="contact-container">
                  <form className="contact-form" onSubmit={handleSubmit}>
                    <div className="col-md-6 mb-3">

                      <label htmlFor="name">Full Name</label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Enter your full name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    <div className="col-md-6 mb-3">

                      <label htmlFor="email">Email Address</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />

                    </div>

                    <div className="col-md-6 mb-3">

                      <label htmlFor="message">Your Message</label>
                      <textarea
                        id="message"
                        name="message"
                        placeholder="Type your message here..."
                        value={formData.message}
                        onChange={handleChange}
                        required
                      ></textarea>
                    </div>
                    <button type="submit">Send Message</button>
                  </form>
                </div>

                {/* Right Side: Info */}
                <div className="contact-info-container">
                  <h3>📞 Get in Touch</h3>
                  <p>
                    <strong>Email:</strong> support@medicore.com
                  </p>
                  <p>
                    <strong>Phone:</strong> +91 9876543210
                  </p>
                  <p>
                    <strong>Location:</strong> Mumbai, India
                  </p>
                </div>
              </div>
            </>
          ) : (
            // ✅ Success Message (after submission)
            <div className="main-content">
              <h2>Message Received!</h2>
              <div className="dashboard-info">
                <p>
                  Thank you for contacting us. We have received your message and
                  will get back to you shortly.
                </p>
                <p>
                  Go back to the{" "}
                  <a href="/" className="home-link">
                    Home Page
                  </a>
                  .
                </p>
              </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}
