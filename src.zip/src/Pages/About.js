import React from "react";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import "../Pages/style.css";
import "../Pages/about.css";

export default function About() {
  return (
    <div className="about-page">
      {/* Sidebar */}
      <Sidebar />

      {/* Right Content */}
      <div className="content-wrapper">
        <Header />

        {/* Main Content */}
        <main className="main-content">
          <div className="about-section">
            <p>
              <strong>MediCore Platform</strong> is a digital health system
              designed to make patient care simple and effective. Our motto is:
              <em>
                {" "}
                "Healing through Technology and Caring Design for Better Health"
              </em>
              .
            </p>

            <h2>Our Mission</h2>
            <p>
              To provide a secure, easy-to-use platform where patients can track
              their immunizations, appointments, and health records digitally.
            </p>

            <h2>Key Features</h2>
            <ul>
              <li>🗓️ Online Appointment Booking</li>
              <li>💉 Vaccine & Immunization Tracker</li>
              <li>📄 Download & Manage Health Reports</li>
              <li>👨‍⚕️ Doctor-Patient Consultation System</li>
              <li>📊 Admin Dashboard for Management</li>
            </ul>

          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}
