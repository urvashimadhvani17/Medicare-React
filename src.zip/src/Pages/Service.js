import React from "react";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import "../Pages/service.css";

const ServicesOnly = () => {
  const services = [
    { title: "Doctor Appointments", subtitle: "Book appointments with trusted doctors easily and quickly." },
    { title: "24/7 Consultation", subtitle: "Get medical advice anytime through our online consultation." },
    { title: "Health Records", subtitle: "Securely store and access your health records in one place." },
    { title: "Pharmacy Orders", subtitle: "Order medicines online and get them delivered at your doorstep." },
    { title: "Lab Tests", subtitle: "Schedule lab tests and view reports directly on the platform." },
    { title: "Specialist Access", subtitle: "Connect with top specialists for expert opinions and treatments." },
  ];

  return (
    <div className="services-page">
      {/* Sidebar */}
      <Sidebar />

      {/* Right Content */}
      <div className="content-wrapper">
        <Header />
      <div class="main-content-area">
        <main className="main-content">
          <div className="services-container">
            <h1 className="services-main-title">MediCore Platform</h1>
            <h2 className="services-title">Our Services</h2>

            <div className="services-grid">
              {services.map((service, index) => (
                <div className="service-card" key={index}>
                  <h3 className="service-heading">{service.title}</h3>
                  <p className="service-subtitle">{service.subtitle}</p>
                </div>
              ))}
            </div>
          </div>
        </main>
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default ServicesOnly;
