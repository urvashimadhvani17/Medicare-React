import React, { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import Footer from "../Components/Footer";

import "../Pages/style.css";
import "../Pages/docstyle.css";
import "../Pages/appt.css";

const API = "http://localhost:5000";

export default function AppointmentForm() {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);

  const [showBox, setShowBox] = useState(false);
  const [selectedAppt, setSelectedAppt] = useState(null);

  // NEW STATE --- Show only book appointment first
  const [showDashboard, setShowDashboard] = useState(false);

  /* -------------------- BOOK APPOINTMENT FORM -------------------- */
  const [bookForm, setBookForm] = useState({
    name: "",
    email: "",
    doctor_id: "",
    date: "",
    time: "",
  });

  const [adminForm, setAdminForm] = useState({
    name: "",
    email: "",
    doctor_id: "",
    date: "",
    time: "",
  });

  /* -------------------- LOAD DOCTORS + APPOINTMENTS -------------------- */
  useEffect(() => {
    fetchDoctors();
    fetchAppointments();
  }, []);

  const fetchDoctors = async () => {
    try {
      const res = await axios.get(`${API}/api/doctor`);
      setDoctors(res.data || []);
    } catch {
      alert("Failed to load doctors.");
    }
  };

  const fetchAppointments = async () => {
    try {
      const res = await axios.get(`${API}/api/appointment`);
      setAppointments(res.data || []);
    } catch {}
  };

  /* -------------------- BOOK APPOINTMENT -------------------- */
  const handleBookChange = (e) =>
    setBookForm({ ...bookForm, [e.target.name]: e.target.value });

  const handleBookSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`${API}/api/appointment`, bookForm);

      alert("Appointment Booked Successfully!");

      setBookForm({
        name: "",
        email: "",
        doctor_id: "",
        date: "",
        time: "",
      });

      fetchAppointments();

      // --- SHOW DASHBOARD AFTER BOOKING ---
      setShowDashboard(true);

    } catch (err) {
      alert("Failed: " + (err.response?.data?.message || err.message));
    }
  };

  /* -------------------- ADMIN ADD/EDIT -------------------- */
  const handleChangeAdmin = (e) =>
    setAdminForm({ ...adminForm, [e.target.name]: e.target.value });

  const resetAdminForm = () =>
    setAdminForm({ name: "", email: "", doctor_id: "", date: "", time: "" });

  const handleSubmitAdmin = async (e) => {
    e.preventDefault();

    try {
      if (selectedAppt) {
        await axios.put(`${API}/api/appointment/${selectedAppt._id}`, adminForm);
        alert("Appointment Updated!");
      } else {
        await axios.post(`${API}/api/appointment`, adminForm);
        alert("Appointment Added!");
      }

      resetAdminForm();
      setSelectedAppt(null);
      setShowBox(false);
      fetchAppointments();
    } catch (err) {
      alert("Failed: " + (err.response?.data?.message || err.message));
    }
  };

  const handleEdit = (a) => {
    setSelectedAppt(a);

    setAdminForm({
      name: a.name,
      email: a.email,
      doctor_id: a.doctor_id?._id || a.doctor_id,
      date: a.date,
      time: a.time,
    });

    setShowBox(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this appointment?")) return;

    try {
      await axios.delete(`${API}/api/appointment/${id}`);
      alert("Deleted!");
      fetchAppointments();
    } catch {
      alert("Delete failed.");
    }
  };

  return (
    <div className="container">
      <Sidebar />
      <div className="contentWrapper">
        <Header />

        <main className="mainContent">

          {/* ---------------- SHOW ONLY BOOK BOX INITIALLY ---------------- */}
          {!showDashboard && (
            <div className="appointment-container">
              <h2>Book Appointment</h2>

              <form className="appointment-form" onSubmit={handleBookSubmit}>
                <div className="appointment-box">

                  <label>Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={bookForm.name}
                    onChange={handleBookChange}
                    required
                  />

                  <label>Email Address</label>
                  <input
                    type="email"
                    name="email"
                    value={bookForm.email}
                    onChange={handleBookChange}
                    required
                  />

                  <label>Choose Doctor</label>
                  <select
                    name="doctor_id"
                    value={bookForm.doctor_id}
                    onChange={handleBookChange}
                    required
                  >
                    <option value="">-- Select Doctor --</option>
                    {doctors.map((doc) => (
                      <option key={doc._id} value={doc._id}>
                        {doc.name} - {doc.specialization}
                      </option>
                    ))}
                  </select>

                  <label>Appointment Date</label>
                  <input
                    type="date"
                    name="date"
                    value={bookForm.date}
                    onChange={handleBookChange}
                    required
                  />

                  <label>Appointment Time</label>
                  <input
                    type="time"
                    name="time"
                    value={bookForm.time}
                    onChange={handleBookChange}
                    required
                  />

                  <button type="submit">Book Now</button>
                </div>
              </form>
            </div>
          )}

          {/* ---------------- DASHBOARD SECTION AFTER BOOKING ---------------- */}
          {showDashboard && (
            <>
              {/* Add Button */}
              <div className="top-section mt-3">
                <button
                  className="btn btn-success"
                  onClick={() => {
                    resetAdminForm();
                    setSelectedAppt(null);
                    setShowBox(true);
                  }}
                >
                  + Add Appointment
                </button>
              </div>

              {/* Add/Edit Box */}
              {showBox && (
                <div className="login-box fade-in mt-4" style={{ width: "600px" }}>
                  <h3>{selectedAppt ? "Edit Appointment" : "Add New Appointment"}</h3>

                  <form onSubmit={handleSubmitAdmin}>
                    <div className="row mt-2">
                      <div className="col-md-6">
                        <label>Full Name</label>
                        <input
                          type="text"
                          name="name"
                          value={adminForm.name}
                          onChange={handleChangeAdmin}
                          required
                        />
                      </div>

                      <div className="col-md-6">
                        <label>Email</label>
                        <input
                          type="email"
                          name="email"
                          value={adminForm.email}
                          onChange={handleChangeAdmin}
                          required
                        />
                      </div>
                    </div>

                    <div className="row mt-3">
                      <div className="col-md-6">
                        <label>Doctor</label>
                        <select
                          name="doctor_id"
                          value={adminForm.doctor_id}
                          onChange={handleChangeAdmin}
                          required
                        >
                          <option value="">Select Doctor</option>
                          {doctors.map((d) => (
                            <option key={d._id} value={d._id}>
                              {d.name} - {d.specialization}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-md-3">
                        <label>Date</label>
                        <input
                          type="date"
                          name="date"
                          value={adminForm.date}
                          onChange={handleChangeAdmin}
                          required
                        />
                      </div>

                      <div className="col-md-3">
                        <label>Time</label>
                        <input
                          type="time"
                          name="time"
                          value={adminForm.time}
                          onChange={handleChangeAdmin}
                          required
                        />
                      </div>
                    </div>

                    <div className="btn-row mt-3">
                      <button className="btn btn-primary" type="submit">
                        {selectedAppt ? "Update Appointment" : "Add Appointment"}
                      </button>

                      <button
                        type="button"
                        className="btn btn-secondary ms-2"
                        onClick={() => setShowBox(false)}
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Table Section */}
              <div className="table-section fade-in">
                <h3>Existing Appointments</h3>

                <table className="doctor-table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Doctor</th>
                      <th>Date</th>
                      <th>Time</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  <tbody>
                    {appointments.length > 0 ? (
                      appointments.map((a, i) => (
                        <tr key={a._id}>
                          <td>{i + 1}</td>
                          <td>{a.name}</td>
                          <td>{a.email}</td>
                          <td>
                            {a.doctor_id?.name
                              ? `${a.doctor_id.name} (${a.doctor_id.specialization})`
                              : "N/A"}
                          </td>
                          <td>{a.date}</td>
                          <td>{a.time}</td>
                          <td>
                            <button className="edit-btn" onClick={() => handleEdit(a)}>
                              ✏ Edit
                            </button>

                            <button
                              className="delete-btn"
                              onClick={() => handleDelete(a._id)}
                            >
                              🗑 Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="7">No appointments found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}

        </main>
        <Footer />
      </div>
    </div>
  );
}
