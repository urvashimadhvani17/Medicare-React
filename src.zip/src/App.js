// src/App.js

import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Pages/Home";
import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Service from "./Pages/Service"; 
import Appointment from "./Pages/Appointment";
import PatientLogin from "./Pages/PatientLogin";
import DoctorLogin from "./Pages/DoctorLogin";
import AdminLogin from "./Pages/AdminLogin.js";


import "./App.css"; 
import "./Pages/patient.css"; 
import "./Pages/docstyle.css"; 
import "./Pages/addstyle.css"; 

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/service" element={<Service />} />
        <Route path="/appointment" element={<Appointment />} />
        <Route path="/patient-login" element={<PatientLogin />} />
        <Route path="/doctor-login" element={<DoctorLogin />} />
        <Route path="/admin-login" element={<AdminLogin />} />
      </Routes>
    </Router>
  );
}

export default App;             