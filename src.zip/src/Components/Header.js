import React from "react";
import '../Pages/style.css';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

export default function Header() {
  return (
    <header className="header">
      <h4>MediCore Platform</h4>
    </header>
  );
}