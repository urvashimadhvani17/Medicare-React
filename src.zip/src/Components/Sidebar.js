import React from "react";
import '../Pages/style.css';
import { Link } from "react-router-dom"; 
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="logo-container text-center">
        <img src="/Images/logo.jpg" alt="Logo" className="logo-img" />
      </div>
     <center> <h5>MediCore Platform</h5></center>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/admin-login"> Admin Login</Link>
        <Link to="/doctor-login"> Doctor Login</Link>
        <Link to="/patient-login">Patient Login</Link>
        <Link to="/appointment">Appointment</Link>
        <Link to="/service">Services</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/about">About</Link>
      </nav>
    </aside>
  );
}
