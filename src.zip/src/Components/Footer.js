// src/components/Footer.jsx
import React from "react";
import '../Pages/style.css';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";


export default function Footer() {
  return (
    <footer className="footer">
      @ MediCore Platform – Healing through technology and caring design for better health.
    </footer>
  );
}
