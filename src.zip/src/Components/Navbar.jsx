
import React from "react";

export default function Navbar() {
  return (
    <nav>
      <h3>Hospital System</h3>
    </nav>
  );
}
